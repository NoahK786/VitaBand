# VitaBand - AI-Powered Stress Detection Wristband

This project provides real-time stress tracking using ESP32 sensors and a Python-based app.