# VitaBand - Stress Monitoring Project

This repository contains firmware and software for the VitaBand project.